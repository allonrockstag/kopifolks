<?php get_header(); ?>

<?php
								
		if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
	elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
	else { $paged = 1; }

				$countpost = 0;
				$args3 = array(
					'posts_per_page' => 10,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'offset' => 5,
					'ignore_sticky_posts' => 1,
					'post_type' => array('post') 
				);
				$args4 = array(
					'posts_per_page' => 10,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'ignore_sticky_posts' => 1,
					'post_type' => array('post') 
				);
				
				?>
				
				<?php if ($paged == 1){?>
					<?php $query = new WP_Query($args3); ?>
				<?php } ?>
				<?php if ($paged > 1){?>
					<?php $query = new WP_Query($args4); ?>
				<?php } ?>

	



			<div id="content">
				<?php include('template-fullscreen-banner.php');?>
				
				<div class="page-header-background">
				<div id="inner-content" class="wrap wrap-home-wide wrap-news-wide cf">
				
				<section class="page-header">
					<div class="page-header-title page-header-title-small news-header">
					<h1>Latest News</h1>
					<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'Menu-News'   // nav name
						)); ?>
				
					</div>
					<!--<div class="page-header-side">
							
					<select>
					  <option value="volvo">News Categories</option>
					  <option value="saab">Saab</option>
					  <option value="mercedes">Mercedes</option>
					  <option value="audi">Audi</option>
					</select>
					
					</div>
					-->
				</section>
				
				<?php if ($paged == 1){?>
				
				<section class="article-hero">
					
					
					<ul class="block-hero m-all t-all d-1of2 cf">
								
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 1, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('post'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php if ( ! has_excerpt() ) {
										      echo '';
										} else { 
										      the_excerpt();
										}
										?>
								</section>
								</a>
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											 
													echo '<span>' . $term->name . '</span>';
										
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
									</p>
							</article>
							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
									
								</ul>
								
								
								
								<ul class="block-hero block-hero-a m-all t-1of2 d-1of4 cf">
								
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 2, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('post'), 'offset' => 1 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li class="block-hero-1">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 

				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									<section class="block-excerpt">
									<?php if ( ! has_excerpt() ) {
										      echo '';
										} else { 
										      the_excerpt();
										}
										?>
								</section>
									
								</a>
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
									</p>
									
									
							</article>
							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
									
								</ul>	
								
									
									<ul class="block-hero block-hero-a m-all t-1of2 d-1of4 cf">
								
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 2, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('post'), 'offset' => 3 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li class="block-hero-1">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 

				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>


							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
						<section class="block-excerpt">
									<?php if ( ! has_excerpt() ) {
										      echo '';
										} else { 
										      the_excerpt();
										}
										?>
								</section>
								</a>
								
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
									</p>
									
									
							</article>
							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
									
								</ul>	
								
								
				</section>	
				
				<?php } ?>
				
				
					<!-- END FIRST PAGE -->	 
					
					
				
				</div>			
				</div>		

					<div id="inner-content" class="wrap wrap-home-wide cf">

						<main id="main" class="m-all t-2of3 d-2of3 cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
																
							
							
							<ul class="block-std block-std-2">
								
								
								<?php if ($paged == 1){?>
									<!--<h2 class="category-title" itemprop="headline">More News</h2>-->
									
									<?php } else { ?> 
									<h2 class="category-title" itemprop="headline">News - Page <?php echo $paged;  ?></h2>
									<?php } ?>
									
																
								<?php  $countpost = 0; ?>
							
							<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
								$post_type_name = get_post_type( $post->ID );
								$post_type = get_post_type_object( get_post_type($post) );
								$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
								$largeimg = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large', false, '' );
									$largeimgsrc = $largeimg[0];
								 $countpost++;
							?>
						 	
						 	
						 	  <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $largeimgsrc; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								
									<?php if ( ! has_excerpt() ) { ?>
										 <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<? } else {  ?>
										      <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<?php } ?>
								
								
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
                                     <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
							</article></a>
							
							
										  </li>						 	
						 	
							 <?php endwhile; ?>
									<!-- pagination -->
									<div class="pagination-custom">
									<?php 
									previous_posts_link('&laquo; Previous');
								    next_posts_link( 'More News &raquo;', $query->max_num_pages );
									
								    wp_reset_postdata();	
									?>
									</div>
									<?php else : ?>
									<!-- No posts found -->
									<?php $countpost=0; endif; ?>
		
									</ul>


						</main>


						
					<div id="sidebar-all" class="m-all t-1of3 d-1of3 cf">
					<?php get_sidebar('news'); ?>
				</div>

				</div>
				
				
				
						
						

			</div>


<?php get_footer(); ?>
