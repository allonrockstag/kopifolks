			
			<div class="md-modal md-effect-7" id="modal-7"> 
			<div class="md-content">
				<div>
					
				<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
					<input id="searchinput" class="sb-search-input" placeholder="Search kopifolks.com" type="text" value="" name="s" id="s" autofocus>
					<input class="sb-search-submit" type="submit" value="">
					<input type="hidden" name="post_type" value="all" />
					
					
				</form>
				<button class="md-close"><img src="<?php echo get_template_directory_uri(); ?>/library/images/btn-close.png"></button>
					
				</div>
				
				<section class="search-content">
					
					<div class="m-all t-1of2 d-1of2 cf">
						<h4>Featured</h4>
						<ul class="search-block-item">
							
								<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 1,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('feature'),
									'post__in'  => $sticky_posts,
									'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 

									     	
									      <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
										
									<h2 class="entry-title"><?php the_title(); ?></h2>
									
								</a>
								
								<p class="byline entry-meta vcard">
									<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											
												echo '<span>' . $term->name . '</span>';
												
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
									</p>
							</article>
							
							
										  </li>
							
						
									    
									  <?php
									endforeach; 
									wp_reset_postdata();
									$countpost=0;
									?>
									

								
									</ul>
									
									
					</div>
					<div class="m-all t-1of2 d-1of2 cf search-content-list last-col">
						
						<div class="m-1of3 t-1of3 d-1of3 cf">			
						<h4>Quick Links</h4>
						<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => '',
						'menu' 			=> 'QuickLinks' 
						
						)); ?>
						</nav>
						<h4><a href="<?php echo home_url(); ?>/featured">Featured</a></h4>
						<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => '',
						'menu' 			=> 'Menu-Featured' 
						
						)); ?>
						</nav>
						
						</div>
						
						<div class="m-1of3 t-1of3 d-1of3 cf">			
						
						<h4><a href="<?php echo home_url(); ?>/eat">What To Eat</a></h4>
						<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => '',
						'menu' 			=> 'Menu-Eat' 
						
						)); ?>
						</nav>
						<h4><a href="<?php echo home_url(); ?>/news">News</a></h4>
						<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => '',
						'menu' 			=> 'Menu-News' 
						
						)); ?>
						</nav>

						</div>
						<div class="m-1of3 t-1of3 d-1of3 last-col cf">			
						<h4><a href="<?php echo home_url(); ?>/video">Videos</a></h4>
						<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => '',
						'menu' 			=> 'Menu-Videos' 
						
						)); ?>
						</nav>
						</div>
									
					</div>
					
				</section>	
				
				
			</div>
			
			
			</div>
			
		<div class="md-overlay"></div><!-- the overlay element -->
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/modalEffects-min.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/cssParser-min.js"></script>
		<script>
			// this is important for IEs
			var polyfilter_scriptpath = '/js/';
		</script>
		
		
		
	
	
		<footer class="footer" id="footer" role="contentinfo" itemscope itemtype="http://schema.org/WPFooter">
				<div class="footer-middle">
					<div id="inner-footer" class="wrap cf">
					
					<div class="m-all t-all d-all">
					
					<nav role="navigation" class="footer-nav-main">
						<?php wp_nav_menu(array(
    					'menu' => __( 'Footer Links', 'bonestheme' ),   // nav name
    					'menu_class' => 'footer-nav cf',            // adding custom nav class
    					'theme_location' => 'footer-links',             // where it's located in the theme
    					'before' => '',                                 // before the menu
    					'after' => '',                                  // after the menu
    					'link_before' => '',                            // before each link
    					'link_after' => '',                             // after each link
    					'depth' => 0,                                   // limit the depth of the nav
    					'fallback_cb' => 'bones_footer_links_fallback'  // fallback function
						)); ?>
						</nav>                  	
					
					</div>
					<div class="m-all t-all d-all cf">
						<section class="ac-container-footer">
	                  <?php $countfaq = 1; ?>
	                 
						<div class="ac-container-box" id="footer-topics">
								<input id="ac-<?php echo $countfaq ?>c" name="accordion-<?php echo $countfaq ?>c" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>c">Find Food</label>
								<article class="ac-small">
									<nav role="navigation">
						<?php wp_nav_menu( array(
						'menu_class'    => 'footer-nav-directory cf',
						'menu' 			=> 'FindFood' 
						
						)); ?>
						</nav>
								</article>
						</div>
						
                  	</section>
						
						
					</div>
					
					
					<div class="m-all t-all d-all">
						
					<div class="footer-logo">
						<img src="<?php bloginfo( 'template_url' ); ?>/library/images/kopifolks-logo-trans.png" />
					</div>
					
					<nav role="navigation" class="footer-nav-main">
						<?php wp_nav_menu( array(
						'menu_class'    => 'footer-nav-2 cf',
						'menu' 			=> 'FooterNav2' 
						
						)); ?>
						</nav>                  	
					
					</div>
					
					

						<div class="m-all t-all d-all cf last-col">
							<ul class="footer-social">
								<li class="footer-icon"><a href="https://www.facebook.com/kopifolks/"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://twitter.com/kopifolks?lang=en"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.youtube.com/kopifolks"><i class="fa fa-youtube-play" aria-hidden="true"></i></a></li>
								<li class="footer-icon"><a href="https://www.instagram.com/kopifolks_/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
							</ul>
						</div>

						
					
					

					</div>
					
				</div>
				
				<div class="footer-end">
				<div id="inner-footer" class="wrap cf">
				<div class="m-all t-all d-all cf">
					<p class="source-org copyright">&copy; <?php echo date('Y'); ?> Rockstagvid Pte Ltd. All Rights Reserved.<br/>
					<a href="<?php echo get_home_url(); ?>/privacy">Privacy Policy</a> | <a href="<?php echo get_home_url(); ?>/terms-of-service">Terms of Service</a></p>
				</div>
				</div>
				</div>

			</footer>

		</div>

		<?php // all js scripts are loaded in library/bones.php ?>
		<?php wp_footer(); ?>
		
		
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/classie.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/library/js/fluidvids.min.js"></script>
		<script src="https://code.jquery.com/jquery-2.2.4.min.js"
			  integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44="
			  crossorigin="anonymous"></script>
		<?php include('jscript-main.php');?>
	


	</body>

</html> <!-- end of site. what a ride! -->
