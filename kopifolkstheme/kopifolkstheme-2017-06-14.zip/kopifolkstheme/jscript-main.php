 <script type="text/javascript">
 jQuery(document).ready(function($){
	//if you change this breakpoint in the style.css file (or _layout.scss if you use SASS), don't forget to update this value as well
	var MQL = 6000;

	//primary navigation slide-in effect
	if($(window).width() > MQL) {
		var headerHeight = $('.cd-header').height();
	
			var headerHeight = 150;

		
		$(window).on('scroll',
		{
	        previousTop: 0
	    }, 
	    function () {
		    var currentTop = $(window).scrollTop();
		  
		    //check if user is scrolling up
		    if (currentTop < this.previousTop) {
		    	//if scrolling up...
		    	if($(window).width() > 767) {
					if (currentTop > 0 && $('.cd-header').hasClass('is-fixed')) {
			    		$('.cd-header').addClass('is-visible');
			    	} else {
			    		$('.cd-header').removeClass('is-visible is-fixed');
			    	}
				} else {
					if (currentTop > 0 && $('.cd-header').hasClass('is-fixed')) {
			    		$('.cd-header').addClass('is-visible');
			    	} else {
			    		$('.cd-header').removeClass('is-visible is-fixed');
			    	}
				}

		    	
		    } else {
		    	//if scrolling down...

		    	if($(window).width() > 767) {
		    			$('.cd-header').removeClass('is-visible');
				    	if( currentTop > headerHeight && !$('.cd-header').hasClass('is-fixed')) {
				    		$('.cd-header').addClass('is-fixed');
				    	} 
		    	} else {
		    			
				    	if( currentTop > 250 && !$('.cd-header').hasClass('is-fixed')) {
				    		//$('.cd-header').addClass('is-fixed is-visible');
				    	} 
		    	}

		    	
		    }
		    this.previousTop = currentTop;
		});
	}

	//open/close primary navigation
	$('.cd-primary-nav-trigger').on('click', function(){
		$('.cd-menu-icon').toggleClass('is-clicked'); 
		$('.cd-header').toggleClass('menu-is-open');
		
		//in firefox transitions break when parent overflow is changed, so we need to wait for the end of the trasition to give the body an overflow hidden
		if( $('.cd-primary-nav').hasClass('is-visible') ) {
			$('body').unbind('touchmove');
			$('body').removeClass('overflow-hidden');
			$('body').removeClass('body-no-scroll');
			$('.cd-primary-nav').removeClass('is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend',function(){
				$('body').removeClass('overflow-hidden');
			});
		} else {
			$('body').bind('touchmove', function(e){e.preventDefault()});
			$('body').addClass('body-no-scroll');
			$('.cd-primary-nav').addClass('is-visible').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend',function(){
				$('body').addClass('overflow-hidden');
			});	
		}
	});
});
 
 
 

			fluidvids.init({
			  selector: ['iframe'],
			  players: ['www.youtube.com', 'player.vimeo.com']
			});
			
			$(function(){
			$('#section-iconbox-1 iframe[src*="youtube.com"]').attr('id','video1');
			$('#section-iconbox-2 iframe[src*="youtube.com"]').attr('id','video2');
			$('#section-iconbox-3 iframe[src*="youtube.com"]').attr('id','video3');
			$('#section-iconbox-4 iframe[src*="youtube.com"]').attr('id','video4');
			$('#section-iconbox-5 iframe[src*="youtube.com"]').attr('id','video5');
			$('#section-iconbox-6 iframe[src*="youtube.com"]').attr('id','video6');
			$('#section-iconbox-7 iframe[src*="youtube.com"]').attr('id','video7');
			$('#section-iconbox-8 iframe[src*="youtube.com"]').attr('id','video8');
			});



			(function() {

				[].slice.call( document.querySelectorAll( '.tabs' ) ).forEach( function( el ) {
					new CBPFWTabs( el );
				});

			})();
			
			
			
			// global variable for the player
			var player1;
			var player2;
			var player3;
			var player4;
			var player5;
			var player6;
			var player7;
			var player8;
			
			// this function gets called when API is ready to use
			function onYouTubePlayerAPIReady() {
			  // create the global player from the specific iframe (#video)
			  player1 = new YT.Player('video1', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player2 = new YT.Player('video2', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player3 = new YT.Player('video3', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player4 = new YT.Player('video4', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player5 = new YT.Player('video5', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  player6 = new YT.Player('video6', {
			    events: {
			      // call this function when player is ready to use
			      'onReady': onPlayerReady
			    }
			  });
			  
			}
			  var pauseButton1 = document.getElementById("pause-button-1");
			  var pauseButton2 = document.getElementById("pause-button-2");
			  var pauseButton3 = document.getElementById("pause-button-3");
			  var pauseButton4 = document.getElementById("pause-button-4");
			  var pauseButton5 = document.getElementById("pause-button-5");
			  var pauseButton6 = document.getElementById("pause-button-6");
			  
			  
			function onPlayerReady(event) {
			  //var pauseButton = document.getElementsByClassName('tab-not-current');
			  pauseButton1.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton2.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton3.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton4.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton5.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  pauseButton6.addEventListener("click", function() {
			    player1.pauseVideo();
			    player2.pauseVideo();
			    player3.pauseVideo();
			    player4.pauseVideo();
			    player5.pauseVideo();
			    player6.pauseVideo();
			  });
			  
			}
			
			// Inject YouTube API script
			var tag = document.createElement('script');
			tag.src = "//www.youtube.com/player_api";
			var firstScriptTag = document.getElementsByTagName('script')[0];
			firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
		
		

 </script>