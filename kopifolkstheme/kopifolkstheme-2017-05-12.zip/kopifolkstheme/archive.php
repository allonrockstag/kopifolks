<?php get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap cf">
					
					<div class="m-all t-all d-all cf">
					<?php
							the_archive_title( '<h1 class="page-title">', '</h1>' );
							the_archive_description( '<div class="taxonomy-description">', '</div>' );
							?>
					</div>
							
						<main id="main" class="m-all t-2of3 d-2of3 cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							
							
							<ul class="block-list">
								
								


								<?php  $countpost = 0; ?>
							<?php if (have_posts()) : while (have_posts()) : the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
							    $post_type = get_post_type_object( get_post_type($post) );
							    $shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
							     $countpost++;
							?>

							<li class="list-item">
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');">
									<?php 
										if( get_post_type() == 'video' ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
								</div>  </a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimage">
					             	<?php 
										if( get_post_type() == 'video' ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
				             	</div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									<p class="byline entry-meta vcard">
                                     <span><?php the_time('F j, Y'); ?></span>
									</p>
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section></a>
								
							</article>
							
							</li>



							<?php endwhile; ?>

									<?php bones_page_navi(); ?>

							<?php else : ?>

									<article id="post-not-found" class="hentry cf">
										<header class="article-header">
											<h1><?php _e( 'No Articles Yet', 'bonestheme' ); ?></h1>
										</header>
										<footer class="article-footer">
												<p>Can't find what you're looking for? Try looking again, or go back to our <a href="<?php echo get_home_url(); ?>">Home Page</a>.</p>
										</footer>
									</article>

							<?php endif; ?>
							
							</ul>

						</main>
						
						<div class="m-all t-1of3 d-1of3 cf last-col">
						<?php get_sidebar(); ?>
				</div>
				
				

				</div>

			</div>

<?php get_footer(); ?>
