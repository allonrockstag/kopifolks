
              <?php
                /*
                 * This is the default post format.
                 *
                 * So basically this is a regular post. if you don't want to use post formats,
                 * you can just copy ths stuff in here and replace the post format thing in
                 * single.php.
                 *
                 * The other formats are SUPER basic so you can style them as you like.
                 *
                 * Again, If you want to remove post formats, just delete the post-formats
                 * folder and replace the function below with the contents of the "format.php" file.
                */
              ?>
			  
				 
              <article id="post-<?php the_ID(); ?>" <?php post_class('cf'); ?> role="article" itemscope itemprop="blogPost" itemtype="http://schema.org/BlogPosting">
	                <div class="m-all t-all d-all last-col cf">
		                
		                <div class="post-hero">
			                 <?php if(has_post_thumbnail()) { ?>
		         <?php $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); ?>
				<img src="<?php echo $featuredImage; ?>">
	            <?php } else { ?>
	             
	            <?php } ?>
		                </div>
	             	            
	                </div>
	            <div class="m-all t-all d-5of7 post-hero-article cf">
		            	<div class="post-header post-header-hero">
                <header class="article-header entry-header">
					
					<p class="byline entry-meta vcard">
						<?php $countterm = 1; ?>
										<?php if( get_post_type() == 'feature' ) { ?>
											<?php $term_list = wp_get_post_terms($post->ID, 'feature-type'); ?>
										<?php } else if( get_post_type() == 'guide' ) { ?>
										<?php $term_list = wp_get_post_terms($post->ID, 'category'); ?>
										<?php } else { ?>
										<?php $term_list = wp_get_post_terms($post->ID, 'category'); ?>
										<?php } ?>
										
										<?php if( get_post_type() == 'guide' ) { ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/food-guide';
													echo '">';
													echo '<span>' . 'Food Guide' . '</span>';
													echo '</a>';
												?>
										<?php } else if( get_post_type() == 'feature' ) { ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/featured';
													echo '">';
													echo '<span>' . 'Featured' . '</span>';
													echo '</a>';
												?>
										<?php } else if( get_post_type() == 'video' ) { ?>
											<?php 	echo '<a href="';
													echo get_home_url();
													echo '/video';
													echo '">';
													echo '<span>' . 'Video' . '</span>';
													echo '</a>';
												?>
										<?php } else { ?>
											
											<?php
												if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
												    foreach ( $term_list as $term ) { 
													 	$term_link = get_term_link( $term );
													    // If there was an error, continue to the next term.
													    if ( is_wp_error( $term_link ) ) {
													        continue;
													    } 
														 echo '<a href="' . esc_url( $term_link ) . '">';   
														 echo '<span>' . $term->name . '</span>';
														 echo '</a>';		
												    }
												}
											?>
										<?php } ?>
										<?php $countterm = 1; ?>
											
											

                  </p>
                  
                  
                  <h1 class="entry-title single-title" itemprop="headline" rel="bookmark"><?php the_title(); ?></h1>
                  
                  <?php if ( has_excerpt() ) { ?>
					    <p class="excerpt"><?php echo get_the_excerpt(); ?></p>
					<?php } else { ?>
					    
					<?php } ?>
					
					
					<span class="fb-count"><a href="#comment"><fb:comments-count href=<?php the_permalink(); ?>></fb:comments-count> Comments</a></span>
					
                  <hr>
                  
		         <span class="author">	
				<?php $author = get_the_author(); ?>
				<p>By 
				<?php if($author == 'admin'){ ?>
					Akiba Press
				<?php } else { ?>
					<?php echo $author; ?>	
				<?php } ?>
				
				<time class="update entry-time" datetime="<?php get_the_time('Y-m-d')?>" itemprop="datePublished"><?php the_time('F j, Y'); ?></time>
				</p>
				</span>
				
				<span class="share-this">	
				
				<ul class="post-share-tablet">
					<h4>Share</h4>
					  	<li class="share-fb"><a href="http://www.facebook.com/sharer.php?u=<?php echo get_permalink(); ?>" target="_blank"><span>Share</span></a></li>
					  	<li class="share-twitter"><a href="https://twitter.com/share?url=<?php echo get_permalink(); ?>" target="_blank"><span>Tweet</span></a></li>
    <li class="share-reddit"><a href="http://reddit.com/submit?url=<?php echo get_permalink(); ?>" target="_blank"><span>Reddit</span></a></li>
					  	<li class="share-comment"><a href="#comment"><span>Comments</span></a></li>
				  	</ul>
				</span>
				

                </header> <?php // end article header ?>
                
					</div> <!-- END POST HEADER -->
	           
	           
	           
	          
	          <!-- <section class="adspace-banner"> 
		          <span></span>
	           </section>
	           
	           -->
	           <section class="wrap-post-article">
		           
				<div class="m-all t-all d-all cf"> <!-- POST ARTICLE -->
					
				
				
				
				<div class="post-article post-article-hero">
					
                <section class="entry-content cf" itemprop="articleBody">
				
					
	               
                  <?php
                    // the content (pretty self explanatory huh)
                    the_content();

                    /*
                     * Link Pages is used in case you have posts that are set to break into
                     * multiple pages. You can remove this if you don't plan on doing that.
                     *
                     * Also, breaking content up into multiple pages is a horrible experience,
                     * so don't do it. While there are SOME edge cases where this is useful, it's
                     * mostly used for people to get more ad views. It's up to you but if you want
                     * to do it, you're wrong and I hate you. (Ok, I still love you but just not as much)
                     *
                     * http://gizmodo.com/5841121/google-wants-to-help-you-avoid-stupid-annoying-multiple-page-articles
                     *
                    */
                    wp_link_pages( array(
                      'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'bonestheme' ) . '</span>',
                      'after'       => '</div>',
                      'link_before' => '<span>',
                      'link_after'  => '</span>',
                    ) );
                  ?>
                </section> <?php // end article section ?>

                <footer id="comment" class="article-footer">

                 

                  <?php the_tags( '<p class="tags"><span class="tags-title">' . __( '', 'bonestheme' ) . '</span> ', '', '</p>' ); ?>
                  	
             
        <div id="fbcomments"><div id="fb-root"></div>
<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script>
<fb:comments href="<?php the_permalink();?>" data-width="100%" data-numposts="5" data-colorscheme="light" ></fb:comments></div>
  


                </footer> <?php // end article footer ?>

               
                
                
				</div>
                 
                 
                 
                 </div>
                 
	           </section> <!--end wrap-post-article -->
                 
			   </div>
	            
	            <div class="m-all t-all d-2of7 last-col cf post-sidebar post-sidebar-huge">
						<?php get_sidebar('post'); ?>
						
						<section class="transparent-banner banner-post-sidebar">
							<div class="banner-type-mobilebanner banner-mobile">This is an Ad Space for mobile</div> 	
							<div class="banner-type-skyscraper banner-desktop">This is an Ad Space for desktop</div> 		
							</section>
							
							
					</div>

              </article> <?php // end article ?>
              
              
			
			 
			 
		 	