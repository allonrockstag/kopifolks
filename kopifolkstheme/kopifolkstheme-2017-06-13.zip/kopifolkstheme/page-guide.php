<?php
/*
 Template Name: Food Guide
*/
?>

<?php get_header(); ?>
	
	<?php
								
		if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
	elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
	else { $paged = 1; }

				$countpost = 0;
				$args3 = array(
					'posts_per_page' => 10,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'offset' => 0,
					'ignore_sticky_posts' => 1,
					'post_type' => array('guide') 
				);
				
				$args4 = array(
					'posts_per_page' => 10,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'ignore_sticky_posts' => 1,
					'post_type' => array('guide') 
				);
				
				?>
				<?php if ($paged == 1){?>
					<?php $query = new WP_Query($args3); ?>
				<?php } ?>
				<?php if ($paged > 1){?>
					<?php $query = new WP_Query($args4); ?>
				<?php } ?>
				
				
	
	
			<div id="content">
				<?php include('template-fullscreen-banner.php');?>
				
				<div class="page-header-background page-header-background-2">
				<div id="inner-content" class="wrap cf">
				<section class="page-header">
					<div class="page-header-title page-header-title-small">
					<h1>Find Food</h1>
					</div>
					
					<section class="ac-container-guide">
	                  <?php $countfaq = 1; ?>
	                 
						<div class="ac-container-box" id="footer-topics">
								<input id="ac-<?php echo $countfaq ?>z" name="accordion-<?php echo $countfaq ?>z" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>z">Food</label>
								
						</div>
						
						<? $countfaq++; ?>
						<div class="ac-container-box" id="footer-topics">
								<input id="ac-<?php echo $countfaq ?>z" name="accordion-<?php echo $countfaq ?>z" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>z">Place</label>
						</div>
							<? $countfaq++; ?>
						<div class="ac-container-box" id="footer-topics">
								<input id="ac-<?php echo $countfaq ?>z" name="accordion-<?php echo $countfaq ?>z" type="checkbox" />
								<label class="comment-label" for="ac-<?php echo $countfaq ?>z">Occasion</label>
						</div>
						 <?php $countfaq = 1; ?>
						 
						<article id="ac-<?php echo $countfaq ?>y" class="ac-small ac-guide-off">
								<!--<nav role="navigation">
									<?php wp_nav_menu( array(
									'menu_class'    => 'nav-findfood cf',
									'menu' 			=> 'FindFood' 
									
									)); ?>
								</nav>
								-->
								
								<?php
								$args = array( 'hide_empty=1' );
 
								$terms = get_terms( 'food', $args );
								if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
									
									echo '<ul class="nav-findfood">';
									    foreach ( $terms as $term ) {
									        echo '<li>';
									        echo '<a href="' . esc_url( get_term_link( $term ) ) . '" alt="' . esc_attr( sprintf( __( 'View all post filed under %s', 'my_localization_domain' ), $term->name ) ) . '">' . $term->name . '</a>';
									        echo '</li>';
									    }
									echo '</ul>';
								}	
									
								?>
								</article>
						<? $countfaq++; ?>
								<article id="ac-<?php echo $countfaq ?>y" class="ac-small ac-guide-off">
								
								<?php
								$args = array( 'hide_empty=1' );
 
								$terms = get_terms( 'place', $args );
								if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
									
									echo '<ul class="nav-findfood">';
									    foreach ( $terms as $term ) {
									        echo '<li>';
									        echo '<a href="' . esc_url( get_term_link( $term ) ) . '" alt="' . esc_attr( sprintf( __( 'View all post filed under %s', 'my_localization_domain' ), $term->name ) ) . '">' . $term->name . '</a>';
									        echo '</li>';
									    }
									echo '</ul>';
								}	
									
								?>
								</article>
								
								<? $countfaq++; ?>
								<article id="ac-<?php echo $countfaq ?>y" class="ac-small ac-guide-off">
								<?php
								$args = array( 'hide_empty=1' );
 
								$terms = get_terms( 'occasion', $args );
								if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
									
									echo '<ul class="nav-findfood">';
									    foreach ( $terms as $term ) {
									        echo '<li>';
									        echo '<a href="' . esc_url( get_term_link( $term ) ) . '" alt="' . esc_attr( sprintf( __( 'View all post filed under %s', 'my_localization_domain' ), $term->name ) ) . '">' . $term->name . '</a>';
									        echo '</li>';
									    }
									echo '</ul>';
								}	
									
								?>
								</article>
						
                  	</section>
                  	
                  	
					
					<div class="page-header-side">	
					<!--<select>
					  <option value="volvo">Review Categories</option>
					  <option value="saab">Saab</option>
					  <option value="mercedes">Mercedes</option>
					  <option value="audi">Audi</option>
					</select>
					-->
					</div>
				</section>
				
				<!-- IF IS FIRST PAGE -->
				<?php if ($paged == 1){?>
					
					<section class="article-hero">
								
								
				</section>
					
				<?php } ?>
				
				
					<!-- END FIRST PAGE -->	 	
				</div>
				</div>
				<div id="inner-content" class="wrap cf">
						<main id="main" class="m-all t-all d-all cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
						
						<?php if ($paged == 1){?>
									<h2 class="section-title">Latest Food Guides</h2>
									
									<?php } else { ?> 
									<h2 class="section-title">Latest Food Guides - Page <?php echo $paged;  ?></h2>
									<?php } ?>
									
						<ul class="block-hero block-hero-guide m-all t-all d-all cf">
								
								
									
																
								<?php  $countpost = 0; ?>
							
							<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
								$foodguideimage = get_post_meta($post->ID, 'wpcf-food-guide-image', true);
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));

								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
								$post_type_name = get_post_type( $post->ID );
								$post_type = get_post_type_object( get_post_type($post) );
								$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
								 $countpost++;
							?>
						 	
						 	
						 	 	  <li class="block-hero-guide">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage" style="background-image: url('<?php echo $foodguideimage; ?>');"></div></div></a>		 

				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								</a>
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
                                     <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
									
									
							</article>
							
							
										  </li>
						 	
						 	
						 	
							 <?php endwhile; ?>
									<!-- pagination -->
									<div class="pagination-custom">
									<?php 
									previous_posts_link('&laquo; Previous');
								    next_posts_link( 'More Food Guides &raquo;', $query->max_num_pages );
									
								    wp_reset_postdata();	
									?>
									</div>
									<?php else : ?>
									<!-- No posts found -->
									<?php $countpost=0; endif; ?>
		
									</ul>


							
							
							
						</main>

						

				</div>

			</div>

<?php get_footer(); ?>
