<?php
/*
Template Name: Contact Us
*/
?>

<?php get_header(); ?>

<?php
	
	$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
	$contacttext = get_post_meta($post->ID, 'wpcf-contact-text', true);
	$form = get_post_meta($post->ID, 'wpcf-contact-form', true);
	?>


			<div id="content">
			<div id="inner-content" class="wrap cf">
				<div class="m-all t-all d-all cf">
					<header class="article-header">

									

								</header> <?php // end article header ?>
					
				</div>
			</div>
			
			<div class="standard-header contact-header" style="background-image:url('<?php echo $featuredImage;?>') ;">
				<div class="contact-header-overlay">
					<div id="inner-content" class="wrap wrap-small cf">
						
							<article>
						<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
						<p>	<?php echo apply_filters('the_content',$contacttext); ?></p>
							</article>
					</div>
				</div>
				</div>
				
				
				<div id="form" class="wrap wrap-small cf">
						
						<div class="m-all t-1of2 d-1of2 cf">
							<section id="subscribe">
			
										<?php echo apply_filters('the_content',$form); ?>
			
			
							
							</section>
							
						</div>
						
						
						<main id="main" class="m-all t-1of2 d-1of2 cf last-col standard-body contact-content" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">

									
								</header> <?php // end article header ?>

								<section class="entry-content  cf" itemprop="articleBody">
									<?php
										the_content();

									
										wp_link_pages( array(
											'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'bonestheme' ) . '</span>',
											'after'       => '</div>',
											'link_before' => '<span>',
											'link_after'  => '</span>',
										) );
									?>
								</section> <?php // end article section ?>

								

							</article>
							
							
				
				

							<?php endwhile; ?>
								
							<?php else : ?>

								<article id="post-not-found" class="hentry cf">
									<header class="article-header">
										<h1><?php _e( 'No Articles Yet', 'bonestheme' ); ?></h1>
									</header>
									<footer class="article-footer">
											<p>Can't find what you're looking for? Try looking again, or go back to our <a href="<?php echo get_home_url(); ?>">Home Page</a>.</p>
									</footer>
								</article>
								
								<?php endif; ?>

						</main>
						
						


				</div>
				

			</div>

<?php get_footer(); ?>

