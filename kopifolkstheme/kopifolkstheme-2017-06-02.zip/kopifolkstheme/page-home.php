<?php
/*
 Template Name: Home
*/
?>

<?php get_header('huge'); ?>

 
<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
					
					?>
			<div id="content" class="content-huge">
				
				<section class="home-top">
					<div class="home-top-content"> 
								<ul class="home-hero">
								<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 1,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('post','what-to-eat','feature'),
									'post__in'  => $sticky_posts,
									'ignore_sticky_posts' => 1,
									'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 

									     	
									      <li class="block-hero-1">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
										
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php if ( ! has_excerpt() ) {
										      echo '';
										} else { 
										      the_excerpt();
										}
										?>
								</section>
								</a>
								
								<p class="byline entry-meta vcard">
									<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											
												echo '<span>' . $term->name . '</span>';
												
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
									</p>
							</article>
							
							
										  </li>
							
						
									    
									  <?php
									endforeach; 
									wp_reset_postdata();
									$countpost=0;
									?>
									

								
									</ul>
									
								
						<ul class="home-hero home-hero-2">
								<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 2,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('post','what-to-eat','feature'),
									'post__in'  => $sticky_posts,
									'ignore_sticky_posts' => 1,
									'offset' => 1 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 

									     	
									      <li class="block-hero-1">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
										
									<h2 class="entry-title"><?php the_title(); ?></h2>
									
									<?php if ( ! has_excerpt() ) { ?>
										 
										<? } else {  ?>
										      <section class="block-excerpt"><?php the_excerpt(); ?></section> 
										<?php } ?>
										
									</a>
								
								<p class="byline entry-meta vcard">
									<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											
												echo '<span>' . $term->name . '</span>';
												
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
									</p>
							</article>
							
							
										  </li>
							
						
									    
									  <?php
									endforeach; 
									wp_reset_postdata();
									$countpost=0;
									?>
									
									
									</ul>
						
																		
									<section class="page-header">
					<div class="page-header-title page-header-title-small page-header-popular">
					<h1>Popular This Week</h1>
					<?php wp_nav_menu(array(
    					         'container' => false,                           // remove nav container
    					         'container_class' => '',                 // class of container (should you choose to use it)
    					         'menu' 			=> 'PopularThisWeek'   // nav name
						)); ?>
				
					</div>
				</section>

					</div> <!-- end videos-content -->
					
					
				</section>
				
				
				<section class="home-latest">
					
					<div id="inner-content" class="wrap wrap-home-wide">
						<div class="special-title">
						<h2 class="video-title">The Latest</h2>
							<hr>
						</div> 
						
						<ul class="home-latest-list">
								
							<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 6, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('what-to-eat','post','feature'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li class="block-hero-1">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 

				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>

								</a>
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
													echo '<span>' . $term->name . '</span>';
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
									</p>
									
									
							</article>
							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
									
								</ul>	

					</div>
				</section>
					
					<section class="home-foodguide">
						<div id="inner-content" class="wrap wrap-home-wide">
							
							<h2 class="section-title">Latest Food Guides</h2>
							
							
							
							<ul class="home-guide">
								
								
									
																
								<?php  $countpost = 0; ?>
							
							<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 4,
									'order'=> 'DESC',
									'orderby' => 'date',
									'category_name' => 'food-guide',
									'post_type' => array('what-to-eat'),
									'post__in'  => $sticky_posts,
									'ignore_sticky_posts' => 1,
									'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$foodguideimage = get_post_meta($post->ID, 'wpcf-food-guide-image', true);
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 


						 	
						 	 	  <li>
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage" style="background-image: url('<?php echo $foodguideimage; ?>');"></div></div></a>		 

				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<!--<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
				
								</a>
								
																
							</article> -->
							
							
										  </li>
						 	
						 	
						 	
							  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
		
									</ul>





						</div>
					</section>
				
				
						
					<section class="youtube-banner">
					
					<div id="inner-content" class="wrap wrap-home-wide">
					
						<div class="youtube-banner-container" style="background-image: url('<?php echo get_template_directory_uri(); ?>/library/images/youtube-banner.jpg');">
							<a href="https://youtube.com/kopifolks"><div class="youtube-banner-overlay">
								<article>
									<img src="<?php echo get_template_directory_uri(); ?>/library/images/kopifolks-logo-trans.png">
							<p>Subscribe to our Youtube Channel</p>
							</article>
							</div>
							</a>
						</div>
					

					</div>
				</section>
					

			</div>

<?php get_footer(); ?>
