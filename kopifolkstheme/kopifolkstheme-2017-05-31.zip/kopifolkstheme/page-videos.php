<?php
/*
 Template Name: Videos
*/
?>

<?php get_header(); ?>


	
	<?php
								
		if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
	elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
	else { $paged = 1; }

				$countpost = 0;
				$args3 = array(
					'posts_per_page' => 9,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'offset' => 1,
					'ignore_sticky_posts' => 1,
					'post_type' => array('video') 
				);
				
				$args4 = array(
					'posts_per_page' => 10,
					'paged' => $paged,
					'order'=> 'DESC',
					'orderby' => 'date',
					'ignore_sticky_posts' => 1,
					'post_type' => array('video') 
				);
				
				?>
				<?php if ($paged == 1){?>
					<?php $query = new WP_Query($args3); ?>
				<?php } ?>
				<?php if ($paged > 1){?>
					<?php $query = new WP_Query($args4); ?>
				<?php } ?>
				

				
				

<?php // Calling Youtube Data API.
$subscribers = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id=UCraPOepRh_hgHEiZTSIilgw&key=AIzaSyB4ZmotWlZQN4GeoWZPQZNpBtlvRikgxwM');
// Decoding json response
$response = json_decode($subscribers, true );
// echoing subscribers count.
 $api_response_decoded = intval($response['items'][0]['statistics']['subscriberCount']);
 
 
// GET YOUTUBE ID
$url = $vidyoutube;
parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
$videoid = $my_array_of_vars['v'];
$apikey = 'AIzaSyB4ZmotWlZQN4GeoWZPQZNpBtlvRikgxwM';
 
 //GET VIDEO TITLE
$json = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=snippet');
$json2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=statistics');
$ytdata = json_decode($json);
$json_data = json_decode($json2, true);
$views = $json_data['items'][0]['statistics']['viewCount'];
 ?>

 
 

			<div id="content"> 
				<!-- IF IS FIRST PAGE -->
				<?php if ($paged == 1){?>
				
				<section class="section-videos transition-height">
					<div class="videos-content transition-height">
						<div id="inner-content" class="wrap wrap-full cf transition-height">
							
							<div class="page-header-videos">
								<div class="m-all t-all d-all cf transition-height">
								<ul class="block-hero m-all t-all d-all cf">
								<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 1, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('video'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li class="block-hero-video">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
										<address>Video</address><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
								<p class="byline entry-meta vcard">
									
                                     <span class="watch">Watch Now</span>
									</p>
									
								</a>
								
								
							</article>
							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
								</ul>
															
							</div>
							</div>
						</div> <!-- end inner-content -->
						
						
						
						

					</div> <!-- end videos-content -->
				</section>
				
				<?php } ?> <!-- END FIRST PAGE -->
				
				<section class="videos-content">
					<div id="inner-content" class="wrap wrap-full cf">
						<div class="m-all t-all d-all cf video-area-footer">
							<div class="videos-more">
								
								<?php if ($paged == 1){?>
									<h2 class="video-title">More Videos</h2>
									
									<?php } else { ?> 
									<h2 class="video-title">Videos -  Page <?php echo $paged;  ?></h2>
									<?php } ?>
									
									
								
							</div>
							<div class="youtube-btn">
								<a href="https://www.youtube.com/kopifolks"><span>
								<p>Kopifolks Youtube Channel</p> 
								<address><?php echo $api_response_decoded; ?> Subscribers</address>
								</span></a>
							</div>
						</div>
						</div>
						
				<div id="inner-content" class="wrap wrap-full cf">
				

				
						
				
				
						<main id="main" class="m-all t-2of3 d-3of4 cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
							
					<ul class="video-list">	
											
								<?php  $countpost = 0; ?>
							
							<?php if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
								$post_type_name = get_post_type( $post->ID );
								$post_type = get_post_type_object( get_post_type($post) );
								$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
								 $countpost++;
							?>

				          
				             <li class="list-item">
				             
				            <?php
				                if(has_post_thumbnail()) { ?>
				<div id="backgroundimg" style="background-image: url('<?php echo $featuredImage; ?>');"></div>
				            <?php } else { ?>
				             
								<div id="backgroundimg"></div>
				            <?php } ?>
	
								
								
								<a id="list-item-text" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
									
								<article>
								<h3><?php the_title(); ?></h3>
								<p class="byline entry-meta vcard">
								<span class="watch">Watch Now</span>
								</p>
								</article>
								
								</a>
								
				            </li>
				            
				            
				        <?php endwhile; ?>
									<!-- pagination -->
									<div class="pagination-custom">
									<?php 
									previous_posts_link('&laquo; Previous');
								    next_posts_link( 'More Videos &raquo;', $query->max_num_pages );
									
								    wp_reset_postdata();	
									?>
									</div>
									<?php else : ?>
									<!-- No posts found -->
									<?php $countpost=0; endif; ?>
									
									</ul>
					
					
					
						</main>
						
						
						<div class="m-all t-1of3 d-1of4 cf video-list-side last-col">
						<?php get_sidebar('videos'); ?>
						</div>
						
						
						<div class="m-all t-all d-all cf">
							<div class="youtube-btn youtube-btn-mobile">
							<a href="https://www.youtube.com/kopifolks"><span>
							<p>Kopifolks Youtube Channel</p> 
							<address><?php echo $api_response_decoded; ?> Subscribers</address>
							</span></a>
							</div>
							</div>
						</div>
				
				
				
							
							
				</section><!-- end video-content -->

			</div>

<?php get_footer(); ?>
