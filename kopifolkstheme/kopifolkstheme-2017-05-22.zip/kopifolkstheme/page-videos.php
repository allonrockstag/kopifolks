<?php
/*
 Template Name: Videos
*/
?>

<?php get_header(); ?>

<?php // Calling Youtube Data API.
$subscribers = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id=UCraPOepRh_hgHEiZTSIilgw&key=AIzaSyB4ZmotWlZQN4GeoWZPQZNpBtlvRikgxwM');
// Decoding json response
$response = json_decode($subscribers, true );
// echoing subscribers count.
 $api_response_decoded = intval($response['items'][0]['statistics']['subscriberCount']);
 
 
// GET YOUTUBE ID
$url = $vidyoutube;
parse_str( parse_url( $url, PHP_URL_QUERY ), $my_array_of_vars );
$videoid = $my_array_of_vars['v'];
$apikey = 'AIzaSyB4ZmotWlZQN4GeoWZPQZNpBtlvRikgxwM';
 
 //GET VIDEO TITLE
$json = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=snippet');
$json2 = file_get_contents('https://www.googleapis.com/youtube/v3/videos?id='.$videoid.'&key='.$apikey.'&part=statistics');
$ytdata = json_decode($json);
$json_data = json_decode($json2, true);
$views = $json_data['items'][0]['statistics']['viewCount'];
 ?>

 
 

			<div id="content"> 
				
				<section class="section-videos transition-height">
					<div class="videos-content transition-height">
						<div id="inner-content" class="wrap wrap-full cf transition-height">
							
							<div class="page-header-videos">
								<div class="m-all t-all d-all cf transition-height">
								<h1><span>Videos</span></h1>
								<ul class="block-hero m-all t-all d-all cf">
								<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 1, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('video'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$shortdescription = get_post_meta($post->ID, 'wpcf-short-description', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 
								
										  <li class="block-hero-video">
									  
									  
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer">
									<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>

<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer">
					             	<?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
										<div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								</a>
								
								<p class="byline entry-meta vcard">
									
                                     <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span class="watch">Watch Now</span></a>
									</p>
							</article>
							
							
										  </li>
							
									  
									  <?php
									endforeach; 
									wp_reset_postdata();
									?>
								
								</ul>
															
							</div>
							</div>
						</div> <!-- end inner-content -->
						
						
						
						

					</div> <!-- end videos-content -->
				</section>
				
				
				<section class="videos-content">
					<div id="inner-content" class="wrap wrap-full cf">
						<div class="m-all t-all d-all cf video-area-footer">
							<div class="videos-more">
								<h2 class="category-title">Explore Videos</h2>
							</div>
							<div class="youtube-btn">
								<a href="https://www.youtube.com/kopifolks"><span>
								<p>Kopifolks Youtube Channel</p> 
								<address><?php echo $api_response_decoded; ?> Subscribers</address>
								</span></a>
							</div>
						</div>
						</div>
						
				<div id="inner-content" class="wrap wrap-full cf">
				

				
						<div class="m-all t-1of3 d-2of7 cf video-list-side">
						<?php get_sidebar('videos'); ?>
						</div>
				
				
						<main id="main" class="m-all t-2of3 d-5of7 cf last-col" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
							
					<ul class="video-list">	
						
					
					<?php
				    $loop = new WP_Query( array( 'post_type' => 'video', 'posts_per_page' => 3, 'paged' => $paged ) );
				    if ( $loop->have_posts() ) :
				        while ( $loop->have_posts() ) : $loop->the_post();
				        $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID)); ?>
				            
				            
				            <li class="list-item">
					            <a id="list-item-image" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
					            <?php
				                if(has_post_thumbnail()) { ?>
				                <div id="videoimage" style="background-image: url('<?php echo $featuredImage; ?>');"><span>Video</span></div>	 
				
				            <?php } else { ?>
				             
				             	<div id="videoimage"><span>Video</span></div>

				            <?php } ?>
				            </a>
				            
					            <a id="list-item-text" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span>
												<h3><?php the_title(); ?></h3>
												<p class="byline entry-meta vcard">
										        	<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    //echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 //echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>

												</p>
												</span></a>
												
							
				            
				            </li>
				        <?php endwhile; ?>
				        
				           <?php bones_page_navi(); ?>
				       
				  <?php  endif;
				    wp_reset_postdata();
				?>
				
					</ul>
					
					
					
						</main>

						<div class="m-all t-all d-all cf">
							<div class="youtube-btn youtube-btn-mobile">
							<a href="https://www.youtube.com/kopifolks"><span>
							<p>Kopifolks Youtube Channel</p> 
							<address><?php echo $api_response_decoded; ?> Subscribers</address>
							</span></a>
							</div>
							</div>
						</div>
				
				
				
							
							
				</section><!-- end video-content -->

			</div>

<?php get_footer(); ?>
