<?php
/*
 Template Name: Home
*/
?>

<?php get_header(); ?>


<?php 
	
	if ( get_query_var( 'paged' ) ) { $paged = get_query_var( 'paged' ); }
					elseif ( get_query_var( 'page' ) ) { $paged = get_query_var( 'page' ); }
					else { $paged = 1; }
					
					?>
			<div id="content">
				
				<section class="home-top">
					<div class="home-top-content"> 
						<div id="inner-content" class="wrap wrap-home cf">
							<div class="m-all t-all d-3of5 cf">
								
								<ul class="home-hero">
								<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 1,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('post','review'),
									'post__in'  => $sticky_posts,
									'ignore_sticky_posts' => 1,
									'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 

									     	
									     	<li class="block-hero-1">
									
									  
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');">
									<?php if ( $design == 3 ) { ?>
									    <span class="videotag">Video</span>
									<?php } ?>
									
								</div>
								
									 </a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimage"></div></a>	

				            <?php } ?>


							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
								
									
								
							</article>
							</a>
						</li>
						
									    
									  <?php
									endforeach; 
									wp_reset_postdata();
									$countpost=0;
									?>
								
									</ul>
									
									
																	
									
							</div>
							<div class="m-all t-all d-1of5 cf">
								
									
									<ul class="home-hero home-side">
								<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 2,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('post','review'),
									'post__in'  => $sticky_posts,
									'ignore_sticky_posts' => 1,
									'offset' => 1
									);
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									 $design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									  setup_postdata( $post ); ?> 

									
									
										  <li class="block-small">
									
									  
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');">
									<?php if ( $design == 3 ) { ?>
									    <span class="videotag">Video</span>
									<?php } ?>
									
								</div>  </a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimage"></div></a>	

				            <?php } ?>


							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
								<p class="byline entry-meta vcard"><span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
									
								
							</article>
							</a>
						</li>


									    
									  <?php
									endforeach; 
									wp_reset_postdata();
									$countpost=0;
									?>
								
									</ul>

							
							</div>
							
							
							<div class="m-all t-all d-1of5 cf">
								<ul class="home-hero home-side home-side-right">
								<?php
									$countpost = 0;
									$sticky_posts = get_option( 'sticky_posts' );
									$args = array(
									'posts_per_page' => 2,
									'order'=> 'DESC',
									'orderby' => 'date',
									'post_type' => array('post','review'),
									'post__in'  => $sticky_posts,
									'ignore_sticky_posts' => 1,
									'offset' => 3 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
									 $countpost++;
									  setup_postdata( $post ); ?> 

									
									
										  <li class="block-small">
									
									  
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');">
									<?php if ( $design == 3 ) { ?>
									    <span class="videotag">Video</span>
									<?php } ?>
								</div>  </a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimage"></div></a>	

				            <?php } ?>


							<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								
								<p class="byline entry-meta vcard"><span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
									
								
							</article>
							</a>
						</li>


									    
									  <?php
									endforeach; 
									wp_reset_postdata();
									$countpost=0;
									?>
								
									</ul>
							</div>
							
						</div> <!-- end inner-content -->
						
						
						
						

					</div> <!-- end videos-content -->
				</section>
				
				<div id="inner-content" class="wrap cf">
					<div class="tabs tabs-style-iconbox">
										
										<div class="content-wrap">
											
											
											<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 5, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('video'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
									$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
									$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
									$vidfb = get_post_meta($post->ID, 'wpcf-video-facebook-code', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									 $countpost++;
									  setup_postdata( $post ); ?> 
									  
								<section id="section-iconbox-<?php echo $countpost;?>">
												
												
												
												
												<div class="tab-video-area">
												<?php if($vidtype == '1' && !empty($vidyoutube)){ ?>
												<?php $embed_code = wp_oembed_get($vidyoutube); ?>
												
												<?php echo $embed_code; ?>
															
												<?php } ?>
												
												<?php if($vidtype == '2' && !empty($vidvimeo)){ ?>
												<?php $embed_code = wp_oembed_get($vidvimeo); ?>
												
												<?php echo $embed_code; ?>
															
												<?php }?>
												
												</div>
												<div class="tab-video-text">
													
												<h2><?php the_title(); ?></h2>
												<p><?php the_excerpt(); ?></p>
												<p class="byline entry-meta">
													<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    //echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 //echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
												</p>
												</div>
											</section>
									  
						 	
						 	
									  
									  <?php
									  
									endforeach; 
									wp_reset_postdata();
									?>

								 

										</div><!-- /content -->
									
										<nav class="tab-nav">
										<ul>
											
											
								
								
											<?php
									$countpost = 0;
									$args = array( 'posts_per_page' => 4, 'order'=> 'DESC', 'orderby' => 'date','post_type' => array('video'), 'offset' => 0 );
									$postslist = get_posts( $args );
									foreach ( $postslist as $post ) :
									$content = get_the_content();
									$content = strip_tags($content);
									$contentshort = substr($content, 0, 255);
									$vidtype = get_post_meta($post->ID, 'wpcf-video-type', true);
									$vidyoutube = get_post_meta($post->ID, 'wpcf-video-youtube-link', true);
									$vidvimeo = get_post_meta($post->ID, 'wpcf-video-vimeo-link', true);
									$vidfb = get_post_meta($post->ID, 'wpcf-video-facebook-code', true);
									$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
									$post_type_name = get_post_type( $post->ID );
									$post_type = get_post_type_object( get_post_type($post) );
									 $countpost++;
									  setup_postdata( $post ); ?> 
									  
									  
											<li id="pause-button-<?php echo $countpost;?>" class="tab-not-current"><a href="#section-iconbox-<?php echo $countpost;?>" class="icon icon-home"><span>
												<h3><?php the_title(); ?></h3>
												<p><?php the_excerpt(); ?></p>
												<p class="byline entry-meta vcard">
										        	<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    //echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 //echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>

												</p>
												</span>
												
							<?php
				                if(has_post_thumbnail()) { ?>
				                <div id="videotabimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div>	 
				
				            <?php } else { ?>
				             
				             	<div id="videotabimage"></div>

				            <?php } ?>
				            
				            </a></li>
										
												
 
									  <?php
									  
									endforeach; 
									wp_reset_postdata();
									?>
									
										</ul>
									</nav>
									
								</div><!-- /tabs -->

				</div>
				
				<div id="inner-content" class="wrap wrap-home main-home cf">

						<main id="main" class="m-all t-2of3 d-5of7 cf" role="main" itemscope itemprop="mainContentOfPage" itemtype="http://schema.org/Blog">
								
								<h2 class="category-title" itemprop="headline">More Articles</h2>

								
							<div class="block-more-posts">
									
									<ul class="home-posts-list">
										
										
										
					<?php 
					
					

					$sticky_posts = get_option( 'sticky_posts' );
					$args = array(
					'posts_per_page' => 10,
					'paged' => $paged,
					'order'=> 'DESC',
					'post__not_in'  => $sticky_posts,
					'orderby' => 'date',
					'post_type' => array('post','review')
					);
					$query = new WP_Query($args);
					?>


							<?php if ($query->have_posts()) : while ($query->have_posts()) : $query->the_post(); 
								$featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
								$design = get_post_meta($post->ID, 'wpcf-article-design', true); 
							?>

							<li class="list-item">
					            <a id="list-item-image" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">
					            <?php
				                if(has_post_thumbnail()) { ?>
				                <div id="videoimage" style="background-image: url('<?php echo $featuredImage; ?>');">
					                <?php 
										if( $design == 3 ) { ?>
										    <span>Video</span>
										<?php } ?>
										</div>	 
				
				            <?php } else { ?>
				             
				             	<div id="videoimage">
					             	 <?php 
										if( $design == 3 ) { ?>
										    <span>Video</span>
										<?php } ?>
				             	</div>

				            <?php } ?>
				            </a>
				            
					            <a id="list-item-text" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><span>
												<h3><?php the_title(); ?></h3>
												<p class="byline entry-meta vcard">
										        	<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    //echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 //echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>

												</p>
												</span></a>
												
							
				            
				            </li>

							<?php endwhile; ?>
							<!-- pagination -->
							
							
							<div class="pagination-custom">
							<?php 
							previous_posts_link('&laquo; Newer posts');
						    next_posts_link( 'Older posts &raquo;', $query->max_num_pages );
							
						    wp_reset_postdata();	
							?>
							</div>
							<?php else : ?>
							<!-- No posts found -->
							<?php endif; ?>
							
								</ul>
								</div>
						



						</main>

						<div class="m-all t-1of3 d-2of7 cf">
						<?php get_sidebar(); ?>
						</div>

				</div>

			</div>

<?php get_footer(); ?>
