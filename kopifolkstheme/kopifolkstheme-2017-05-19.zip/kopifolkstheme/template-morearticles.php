<section class="article-morearticles">
					<div class="wrap cf">
						<div class="m-all t-all d-all cf">
							<!--<div class="block-sponsored"></div>-->
						</div>
						<div class="m-all t-all d-1of8 cf">
							<span class="spacer">&nbsp;</span>
						</div>
						<div class="m-all t-all d-3of4 cf">
								<div class="block-more-posts">
									<?php 
									if( get_post_type() == 'post' ) { ?>
									    <h2>More News Like This</h2>
									<?php } elseif ( get_post_type() == 'what-to-eat' ) {?>
										<h2>More Food Like This</h2>	
									<?php } elseif ( get_post_type() == 'video' ) {?>
										<h2>More Videos Like This</h2>
									<?php } else {?>	
										<h2>More Stuff Like This</h2>
									<?php } ?>
									<ul class="more-posts-list">
										<?php $posttype = get_post_type();
											$countpost = 0; ?>
										<?php 
									if( $posttype == 'post' ) { ?>
									    <?php  $loop = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 6, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?> 
									<?php } ?>
									
									<?php if ( $posttype == 'review' ) {?>
										<?php  $loop = new WP_Query( array( 'post_type' => 'review', 'posts_per_page' => 6, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
									<?php } ?> 
									
									<?php if ( $posttype == 'video' ) {?>
										<?php  $loop = new WP_Query( array( 'post_type' => 'video', 'posts_per_page' => 6, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
									<?php } ?>
									
									<?php if ( $posttype !== 'post' && $posttype !== 'review' && $posttype !== 'video') { ?>
										<?php  $loop = new WP_Query( array( 'post_type' => array('post','review','video'), 'posts_per_page' => 6, 'ignore_sticky_posts' => 1, 'post__not_in' => array( $post->ID ), 'paged' => $paged ) ); ?>
										
									<?php } ?>
					<?php			
						if ( $loop->have_posts() ) :
				        while ( $loop->have_posts() ) : $loop->the_post();
				        $featuredImage = wp_get_attachment_url( get_post_thumbnail_id($post->ID));
				        $design = get_post_meta($post->ID, 'wpcf-article-design', true); 
				        $countpost++; ?>
				            
				            
				             <?php if($countpost % 2 == 0){  ?>
							 	 <!--IF NUMBER IS EVEN -->
							 	  <li class="list-item list-item-even">
						 	 <?php } else { ?> 
						 	 <!--IF NUMBER IS ODD -->
							 	  <li class="list-item list-item-odd">
						 	 <?php } ?>
						 		 
									  
									  <?php 
										if( $design == 2 ) { ?>
										    <span class="videotag">Video</span>
										<?php } ?>
									  
						 	
						 	<?php
				                if(has_post_thumbnail()) { ?>
				                  
								 <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>">

								<div id="blockimagecontainer"><div id="blockimage" style="background-image: url('<?php echo $featuredImage; ?>');"></div></div></a>		 
				
				            <?php } else { ?>
				             
				             	<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><div id="blockimagecontainer"><div id="blockimage"></div></div></a>	

				            <?php } ?>



							<article id="post-<?php the_ID(); ?>" <?php post_class( 'cf' ); ?> role="article">	            
									
									<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="entry-title"><?php the_title(); ?></h2>
									

								<section class="block-excerpt">
									<?php the_excerpt(); ?>
								</section>
								</a>
								
								<p class="byline entry-meta vcard">
										<?php
											$term_list = wp_get_post_terms($post->ID, 'category');
											$countterm = 1;
											?>
											<?php
											if ( ! empty( $term_list ) && ! is_wp_error( $term_list ) ){
										   
										    foreach ( $term_list as $term ) { 
										    
											     $term_link = get_term_link( $term );
    
											    // If there was an error, continue to the next term.
											    if ( is_wp_error( $term_link ) ) {
											        continue;
											    }
											
											    
											    echo '<a href="' . esc_url( $term_link ) . '">';
											    
											    if($term->name == 'PS4'){
													 echo '<span class="cat-ps4">' . $term->name . '</span>';
												} else if($term->name == 'Switch'){
													 echo '<span class="cat-switch">' . $term->name . '</span>';
												} else if($term->name == 'Xbox One'){
													 echo '<span class="cat-xbox">' . $term->name . '</span>';
												} else {
													echo '<span>' . $term->name . '</span>';
												}
												
												 echo '</a>';
										       
										    }
										    
										    
										}
											$countterm = 1; ?>
                                     <span class="time"><?php the_time('F j, Y'); ?></span>
									</p>
									
									
							</article>
							
							
										  </li>	
				        <?php endwhile; ?>
				        
				           <?php bones_page_navi(); ?>
				       
				  <?php  endif;
					  $countpost = 0;
				    wp_reset_postdata();
				?>

									</ul>
								</div>
						</div>
						<div class="m-all t-all d-1of8 cf last-col">
							<span class="spacer">&nbsp;</span>
						</div>
					</div>
				</section>